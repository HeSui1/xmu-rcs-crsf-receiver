#ifndef _BSP_USART_H
#define _BSP_USART_H

#include "main.h"




void send_message(void);


#endif 
